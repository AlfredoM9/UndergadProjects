Name  : Alfredo Mejia
NetID : axm180023
Course: SE 3345.004
Assign: Project 2
IDE   : IntelliJ IDEA Community Edition

Files : MyItem.java
	IDedObject.java
	IDedLinkedList.java
	P2Driver.java

I used a terminal to compile the files because it needed arguments to be
passed to the main method, however I did have some trouble at first to
get it compiled in the terminal.

Sample :

Input : 
Insert 22 19 475 1238 9742 0
Insert 12 96 44 109 0
PrintTotal
FindID22
Find 45
PrintTotal
24323  mjbjh kjhkjhkj hjhg 
Insert 56 89 785 587 435 0
PrintTotal
Insert 56 98 34 67 324 0
PrintTotal
Insert 87 547 456 3435 90 0
PrintTotal
DeleteID 
Find 
sdfsdf
FindID 666
End

Output: 
True
True
34
ERROR
ERROR
34
ERROR
True
90
False
90
True
177
ERROR
ERROR
ERROR
NULL
