package Project2;

// Interface used for MyItem class
public interface IDedObject {
    int getID();
    String printID();
}
